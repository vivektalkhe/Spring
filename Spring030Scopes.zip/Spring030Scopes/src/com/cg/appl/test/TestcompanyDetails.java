package com.cg.appl.test;

import org.springframework.context.ApplicationContext;

import com.cg.appl.commons.Address;
import com.cg.appl.commons.CompanyDetails;
import com.cg.appl.util.SpringUtil;

public class TestcompanyDetails {

	public static void main(String[] args) {

		
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		CompanyDetails details=(CompanyDetails) ctx.getBean("companyDetails");
		System.out.println(details.getCompanyName());
		System.out.println(details.getCompanyMotto());
		System.out.println(details.getNiftyRank());
		System.out.println(details.getAddr());
		
	/*	Address addr=ctx.getBean("address",Address.class);
		System.out.println(addr.getLine1());
		System.out.println(addr.getLine2());
		System.out.println(addr.getArea());
		System.out.println(addr.getCity());
		System.out.println(addr.getCountry());
		System.out.println(addr.getPin());*/
		
		
		
		//System.out.println(details);
		
	}

}
