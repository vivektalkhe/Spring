package com.cg.appl.util;

import java.sql.Connection;

public class DbUtilImpl implements DbUtil {
	
	public DbUtilImpl(){
		System.out.println("In Constructor of DbUtil");
	}

	@Override
	public Connection getConnection() {

		System.out.println("In getConnection() of DbUtil");
		return null;
	}
	

}
