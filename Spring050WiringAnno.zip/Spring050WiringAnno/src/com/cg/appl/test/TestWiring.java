package com.cg.appl.test;

import org.springframework.context.ApplicationContext;

import com.cg.appl.dao.EntityDao;
import com.cg.appl.util.SpringUtil;

public class TestWiring {


	public static void main(String[] args) {
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		EntityDao dao=ctx.getBean("entityDao",EntityDao.class);
		System.out.println(dao.hashCode());
		
		dao.getConnection();
		
	}

}
