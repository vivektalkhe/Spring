package com.cg.appl.util;

import java.sql.Connection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class DbUtilImpl implements DbUtil,InitializingBean,DisposableBean,ApplicationContextAware{
	
	private ApplicationContext ctx;
	
	public void setUp(){
		
		System.out.println("In setUp()");
	}
	
	
	public DbUtilImpl(){
		System.out.println("In Constructor of DbUtil");
	}
	public void setX(int x)
	{
		System.out.println("In setX()");
	}
	@Override
	public Connection getConnection() {

		System.out.println("In getConnection() of DbUtil");
		return null;
	}
public void cleanUp(){
		
		System.out.println("In cleanUp()");
	}


@Override
public void afterPropertiesSet() throws Exception {

	
	System.out.println("In AfterPropertiesSet()");
}


@Override
public void destroy() throws Exception {

	System.out.println("In Destroy()");
}


@Override
public void setApplicationContext(ApplicationContext arg0)
		throws BeansException {
	System.out.println("in setApplicationContextAware()");	
	ctx=arg0;
}

}
