package com.cg.appl.dao;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;

@Repository("entityDao")
public class EntityDao {
	
	private DbUtil dbUtil;
	
	
	public EntityDao(){
		
		System.out.println("In Constructor of EntityDao()");
	}
	@PostConstruct
	public void setUp(){
		
		System.out.println("In setUp() of Dao");
	}
	@PreDestroy
	public void cleanUp(){
		
		System.out.println("In cleanUp() of Dao");
	}
	/*@Autowired
	@Qualifier("dbUtil2")*/
	@Resource(name="dbUtil")
	public void setDbUtil(DbUtil dbUtil) {
		System.out.println("In setter of EntityDao");
		this.dbUtil = dbUtil;
	}

	public void getConnection()
	{	
		dbUtil.getConnection();
	}
}
