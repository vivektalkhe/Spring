package com.cg.appl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

//http://localhost:8085/Spring110MVC_Basic/welcome.do
@Controller
public class EmpCrud //extends AbstractController 
{
	
	@RequestMapping("/welcome.do")
	public ModelAndView welcome(){
		
		System.out.println("In Controlling Method");
		String name="Mr.Vivek";
		ModelAndView model=new ModelAndView("welcome");	//nickname of jsp
		model.addObject("customerName", name);
		return model;
	}

	/*@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		System.out.println("In handleRequestInternal Method");
		String name="Mr.Vivek";
		ModelAndView model=new ModelAndView("welcome");	//nickname of jsp
		model.addObject("customerName", name);
		return model;
	}*/

}
