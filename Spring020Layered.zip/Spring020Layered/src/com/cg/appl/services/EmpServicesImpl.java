package com.cg.appl.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
//@Component("empServices")
@Service("empServices")
public class EmpServicesImpl implements EmpServices {
	private EmpDao dao;

	public EmpServicesImpl() {
		System.out.println("In Constructor Of EmpServicesImpl");	
	}
	
	@Resource(name="empDao")
	public void setDao(EmpDao dao) {	//dao
		System.out.println("In setDao()");
		this.dao = dao;
	}



	@Override
	public Emp getEmpDetails() throws EmpException {
		
		
		dao.getEmpDetails();
		return null;
	}

}
