package com.cg.appl.util;

import org.springframework.stereotype.Component;

@Component("dbUtil")
public class EntityManageUtil {

	public EntityManageUtil() {

	System.out.println("In Constructor Of EntityManageUtil");
	}

}
