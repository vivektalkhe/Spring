package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.util.SpringUtil;

public class TestLayering {

	public TestLayering() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		EmpServices empservices=ctx.getBean("empServices",EmpServices.class);
		
		try {
			empservices.getEmpDetails();
		} catch (EmpException e) {
			e.printStackTrace();
		}
	}

}
