package com.cg.appl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;




/*Component:For Every Class
 * Service:For Service Classes
 * Repository:For Dao Classes
 * Controller:For Controller classes of Spring MVC
 * RestController:To Declare Controller classses for publishing Rest Classes
 * 
 * 
*/
//@Component("empDao")
@Repository("empDao")
@Scope("singleton")
public class EmpDaoImpl implements EmpDao {
	private EntityManageUtil util;
	
	
	
	public EmpDaoImpl()
	{
		System.out.println("In Constructor Of EmpDaoImpl");
	}

	
	@Autowired	//Autowiring by type.
	@Qualifier("dbUtil")	////Autowiring by name
	public void setUtil(EntityManageUtil util) {	//util(Property Name)
		System.out.println("In setUtil()");
		this.util = util;
	}



	@Override
	public Emp getEmpDetails() throws EmpException {
		
		
		System.out.println("In getEmpDetails()");
		
		return null;
	}

}
